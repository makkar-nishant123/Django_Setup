from django.apps import AppConfig


class SitecreatorConfig(AppConfig):
    name = 'scheduler_site'
